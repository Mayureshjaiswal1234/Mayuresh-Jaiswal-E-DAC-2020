
 public class CircleArea
 {
  public static void main(String[] args)
  {
      
      double pi = 3.14, r=7.5,area;
      area= pi*r*r;
      System.out.println("Area of circle :" );
   
      System.out.print(area);
  }
}
