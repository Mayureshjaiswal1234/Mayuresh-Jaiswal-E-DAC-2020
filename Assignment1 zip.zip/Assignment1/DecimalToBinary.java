
import java.util.Scanner;
public class DecimalToBinary
{
  public static void  main(String[]args)
{
   Scanner sc= new Scanner(System.in);
   System.out.println("Enter Decimal number");
   
  
   int num =sc.nextInt();
  
   String str = Integer.toBinaryString(num);
   System.out.println("Binary value is " +str);
}
  
}