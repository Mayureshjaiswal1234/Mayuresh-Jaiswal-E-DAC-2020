 class Addition
{
  public static void  main(String[]args)
{
  int a=74,b=36,c;
  c=a+b;
  System.out.println("Addition of Two Numbers is-->>");
  System.out.print(c);
}
}