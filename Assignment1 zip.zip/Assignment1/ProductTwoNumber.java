import java.util.Scanner;
 public class ProductTwoNumber
 {
  public static void main(String[] args)
  {
    Scanner scan = new Scanner(System.in);
      System.out.println("Enter the first number:" );
      int num1 = scan.nextInt();
      System.out.println("Enter the second number:");
      int num2 = scan.nextInt();
      System.out.println(num1 + " x " +num2+" = "+(num1 * num2) );
  }
}
