import java.util.Scanner;
public class Perimeter
{
    int r;
    double pi = 3.14,perimeter;
    Scanner s = new Scanner(System.in);
    void circle()
    {
        System.out.print("Enter radius of circle:");
        r = s.nextInt();
        perimeter = 2 * pi * r;
        System.out.println("Perimeter of circle:"+perimeter);
    }
    
  
     public static void main(String[] args) 
    {
        Perimeter obj = new Perimeter();
        obj.circle();
    }
}
     