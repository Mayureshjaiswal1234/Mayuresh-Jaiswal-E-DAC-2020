
import java.util.Scanner;
public class DecimalToHexa
{
  public static void  main(String[]args)
{
   Scanner sc= new Scanner(System.in);
   System.out.println("Enter Decimal number");
   
  
   int num =sc.nextInt();
  
   String str = Integer.toBinaryString(num);
   System.out.println("Hexadecimal number is " +str);
}
  
}