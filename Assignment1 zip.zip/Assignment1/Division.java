 class Division
{
  public static void  main(String[]args)
{
  int a=50,b=3,c;
  c=a/b;
  System.out.println("Division of Two Numbers-->>");
  System.out.print(c);
}
}